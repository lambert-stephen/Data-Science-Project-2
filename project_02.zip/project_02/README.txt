Member #1 - William Ocampo, wocampo2, 676020425, Scribe

Member #2 - Stephen Lambert, slambe7, 674784220, Project Manager

Member #3 - Jasmine S. Gutierrez, jgutie45, 667750070, Timekeeper

Note: Even though we split up the problems amongst each other, we all helped each other and reviewed the inputted solutions to verify their correctness.

William did problems 3, 4, 5, 6, and 7. Being the Scribe, William completed the meeting minutes, contributed to the analysis of the problems, and was available to help with questions, or problems in the program.

Stephen did problems 1,2,3, and 5. Being the project manager, Stephen set up both meetings, discussed everyones workload, and set guidelines for how the work is distriubted. He also led the meetings and made himself available to contribute to questions about the program, and contributed to the analysis of the problems.

Jasmine did problems 3, 4, 6, 7. Being the timekeeper, jasmine ensured every team member attended the meeting by bringing us all together in voice chat, and ensuring that we meet to discuss the project. Jasmine also contributed a lot to the analysis of problems, and was available to help with questions or problems in the program.

Instructions to run code:

Run the following commands on your terminal to install the necessary packages: $ conda install plotly $ conda install geopandas $ conda install shapely $ conda install pyshp $ conda install -c plotly plotly-geo

Launch Jupyter Notebook via Anaconda

Navigate to and open project_01.ipynb

Run